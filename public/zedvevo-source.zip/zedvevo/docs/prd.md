# Requirements Document

## 1. Application Overview

**Application Name**: ZedStream

**Description**: A premium music and video streaming platform with integrated awards system, real payment processing via Lipila, comprehensive admin management capabilities, download system, global search, notification system, weekly trending, and enhanced awards features.

## 2. Users and Usage Scenarios

**Target Users**:
- Content Creators: Upload and manage music/video content
- Viewers: Stream, download, search music and videos, participate in awards voting
- Nominees: Register for awards and track nominations
- Administrators: Manage platform content, users, payments, awards, downloads, notifications, trending

**Core Scenarios**:
- Users upload MP3/MP4 files after purchasing upload plans
- Admins upload content without payment
- Users stream and download music and videos
- Users search for songs, videos, artists, albums, nominees
- Users receive notifications for awards, payments, trending
- Users participate in awards by registering as nominees or voting
- Admins manage all platform content, configure pricing, publish monthly winners

## 3. Page Structure and Functionality

```
ZedStream Platform
├── Public Pages
│   ├── Home Page
│   ├── Music Page
│   ├── Videos Page
│   ├── Awards Page
│   ├── Trending Page
│   └── Search Results Page
├── User Pages
│   ├── Upload Page
│   ├── Library Page
│   ├── My Downloads Page
│   ├── Profile Page
│   ├── User Dashboard
│   └── Notifications Page
└── Admin Pages
    └── Admin Dashboard
```

### 3.1 Header (Global Component)

**Brand Section**:
- Left side: ZedStream name with animated circular CD/disc logo
- CD logo features: continuous rotation, realistic disc rings, glowing center, ZedStream branding, smooth animation, stop/slow for reduced motion preference

**Navigation**:
- Desktop: Home | Music | Videos | Awards | Trending | Upload | Library | My Downloads | Profile
- Mobile: Bottom navigation bar with same menu items

**Global Search Bar**:
- Search input field in header
- Live search results while typing
- Search songs, videos, artists, albums, award nominees
- Click result to open content

**Notification Bell**:
- Animated bell icon in header
- Display unread notification count badge
- Click to open notification dropdown panel

**Header Behavior**:
- Sticky positioning
- Glassmorphism effect
- Animated on scroll
- Responsive across devices

### 3.2 Hero Image Slider (Home Page)

**Display**:
- Full-width banner below header
- Image-based backgrounds (Pexels images for demo)
- Dark gradient overlay for text readability
- Text overlay: title, subtitle, call-to-action button

**Slider Features**:
- Automatic slide rotation
- Smooth cinematic transitions
- Ken Burns-style image movement effect
- Slide indicators
- Previous/Next navigation buttons
- Touch/swipe support on mobile
- Pause on user interaction, auto-resume after
- Responsive image sizing

**Banner Content Examples**:
- TRENDING NOW
- ZEDSTREAM AWARDS
- NEW MUSIC
- WATCH NOW

**Admin Banner Management** (via Admin Dashboard):
- Upload banner image
- Set title, subtitle, button text, button destination
- Configure start date, end date
- Toggle active/inactive status
- Set display order
- Unlimited number of banners allowed
- Replace existing banner images

### 3.3 Home Page

**Content Sections**:
- Trending Now: Display trending songs and videos
- Weekly Trending: Display most played songs, most downloaded songs, most viewed videos, most liked songs, most shared content for current week
- Winner of the Month: Display current month's winner with photo, artist name, award/category, month/year, prize, description
- New Releases: Show recently approved uploads
- Popular Music: List most played songs
- Trending Videos: Display most viewed videos
- ZedStream Awards: Show current awards and nominees
- Featured Artists: Highlight popular artists
- Sponsors: Display award sponsors

**Display Style**:
- Animated cards for content items
- Horizontal scrolling sections on mobile
- Premium streaming service visual design

### 3.4 Music Page

**Music Playback**:
- Play/pause controls
- Progress bar
- Volume control
- Like button
- Save to library button
- Download button
- Share button
- View play count, download count, and statistics

**Music Browsing**:
- Browse all approved music uploads
- Filter and search functionality
- Display: song title, artist, album art, duration, play count, download count

### 3.5 Videos Page

**Video Playback**:
- Play/pause controls
- Progress bar
- Volume control
- Fullscreen toggle
- Like button
- Save to library button
- Download button (if enabled by admin)
- Share button
- View statistics

**Video Browsing**:
- Browse all approved video uploads
- Display: video thumbnail, title, artist, duration, view count, download count

### 3.6 Awards Page

**Awards Information**:
- Display current awards and categories
- Show award seasons
- Display nominees per category
- Display voting status and results
- Show winners when announced
- Display past winners
- Show sponsors

**Nominee Registration**:
- User selects award season and category
- Fills registration form
- Uploads images/files
- Pays K25 nominee registration fee via Lipila
- Registration status: Pending Payment, Pending Review, Approved, Rejected, Winner
- Nomination created only after successful payment verification

**Voting**:
- User selects nominee to vote for
- Enters number of votes (minimum K5 per vote)
- Selects payment method: Mobile Money or Card
- Pays via Lipila
- Votes added only after successful payment verification
- User can view their voting history

**Winner of the Month**:
- Display current month's winner
- Show winner photo, artist name, award/category, month/year, prize, description

**Past Winners**:
- Display previous award winners
- Filter by award season, category, year

### 3.7 Trending Page

**Weekly Trending Sections**:
- Most Played Songs: Display top songs by play count for current week
- Most Downloaded Songs: Display top songs by download count for current week
- Most Viewed Videos: Display top videos by view count for current week
- Most Liked Songs: Display top songs by like count for current week
- Most Shared Content: Display top content by share count for current week

**Display**:
- Ranking numbers
- Content details: title, artist, cover art/thumbnail, statistics
- Click to play/view content

### 3.8 Search Results Page

**Search Functionality**:
- Display search results from Supabase database
- Search by title, artist, genre, album
- Show cover artwork and video thumbnails
- Click result to open content

**Filters**:
- All
- Music
- Videos
- Artists
- Awards

**Sort Options**:
- Relevance
- Newest
- Most Played
- Most Downloaded
- Most Viewed

**Display**:
- Only show approved/public content
- Result count
- Content cards with metadata

### 3.9 Upload Page

**Upload Plan Selection**:
- Display available plans:
  - K10: Upload 1 song
  - K100: Unlimited uploads for 7 days
  - K300: Unlimited uploads for 1 YEAR
- User selects plan and proceeds to payment

**Payment Process**:
- User selects payment method: Mobile Money or Card
- **Mobile Money Flow**:
  - User enters phone number
  - Lipila payment request created
  - User confirms payment on mobile device
  - Lipila processes transaction
  - Backend receives webhook from Lipila
  - Backend verifies transaction
  - Plan activated only after successful verification
- **Card Flow**:
  - User redirected to Lipila secure card checkout
  - User enters card details via Lipila interface
  - Lipila processes transaction
  - Backend verifies transaction
  - Plan activated only after successful verification

**Payment Status**:
- Pending: Plan remains inactive until verification
- Successful: Plan activated
- Failed: Plan not activated, user can retry
- Cancelled: Plan not activated
- Insufficient funds: Plan not activated, clear message displayed: \"Payment unsuccessful. Your payment could not be completed because there were insufficient funds. Please add sufficient funds and try again.\"
- Invalid transaction: Plan not activated

**Music Upload** (after active plan):
- User selects MP3 file from device
- Enters metadata: song title, artist name, album, genre
- Uploads cover artwork
- Uploads file to Supabase Storage
- Metadata saved to Supabase PostgreSQL
- Upload progress indicator displayed
- Confirmation after successful upload

**Video Upload** (after active plan):
- User selects MP4 file from device
- Enters metadata: video title, artist name, description
- Uploads file to Supabase Storage
- System auto-generates thumbnail from video
- Metadata and thumbnail saved to Supabase
- Upload progress indicator displayed
- Confirmation after successful upload

**Admin Upload** (Admin/Super Admin only):
- Admin uploads unlimited MP3 and MP4 without paying any plan
- Admin uploads never require K10/K100/K300 packages or payment
- Admin uploads are approved by default or saveable as draft
- Admin can upload: songs, videos, cover artwork, hero banners, sponsor logos, award images

### 3.10 Library Page

**User's Saved Content**:
- Display songs saved by user
- Display videos saved by user
- Play/remove from library options

### 3.11 My Downloads Page

**Downloaded Content**:
- Display all music downloaded by user
- Display all videos downloaded by user
- Show download date
- Play/re-download options

### 3.12 Profile Page

**User Information**:
- Display username, email, profile picture
- Edit profile option

### 3.13 Notifications Page

**Notification List**:
- Display all notifications from database
- Notification types:
  - Award winners announced
  - Winner of the Month published
  - Weekly trending updated
  - New awards opened
  - Voting opened/closing
  - Nomination approved/rejected
  - Successful/failed payments
  - Package expiry reminders

**Notification Actions**:
- Open notification
- Mark as read
- Delete notification
- Mark all as read

### 3.14 User Dashboard

**Dashboard Sections**:
- Profile summary
- Active upload plan and expiry date
- Upload allowance remaining
- My Music: List of user's uploaded songs with edit/replace MP3/delete options
- My Videos: List of user's uploaded videos with edit/replace MP4/delete options
- Payments: Payment history with transaction details
- Awards: User's award nominations
- Nominations: Nomination status (Pending Payment, Pending Review, Approved, Rejected, Winner)
- Votes: Voting history
- Downloads: Download history
- Statistics: Play counts, view counts, download counts for user's content
- Notifications: System notifications

**Content Management**:
- User can edit only their own uploads
- Edit song: Update metadata, replace MP3 file, delete song
- Edit video: Update metadata, replace MP4 file (auto-generates new thumbnail), delete video

### 3.15 Admin Dashboard

**User Management**:
- View all users
- Manage user accounts
- View user upload activity

**Content Management**:
- Approve/reject uploaded songs
- Approve/reject uploaded videos
- Edit/delete any song or video
- Manage artists
- Enable/disable downloads per video

**Download Management**:
- View all download records
- View download statistics per content
- Enable/disable download functionality per video

**Search Management**:
- View search logs
- Manage search indexing

**Upload Plans Management**:
- Change K10 plan price
- Change K100 plan price
- Change K300 plan price
- Changes saved to Supabase and reflected immediately

**Payment Management**:
- View all payment transactions
- View payment status: successful, pending, failed
- View transaction details: user ID, amount, payment method, Lipila transaction ID, package, status, date, failure reason

**Awards Management**:
- Create/edit/delete award seasons
- Create/edit/delete award categories
- Manage nominees per category
- View voting results
- Announce winners
- Set grand prizes
- Change K25 nominee registration fee
- Change K5 minimum vote price
- Publish Winner of the Month

**Nominee Management**:
- View all nominee registrations
- Approve/reject nominations
- Update nomination status
- View payment verification status

**Voting Management**:
- View all votes
- View vote totals per nominee
- Verify payment status for votes

**Winner of the Month Management**:
- Select one winner per month
- Upload winner photo
- Enter artist name, award/category, month/year, prize, description
- Publish winner
- Auto-notify users when published

**Sponsors Management**:
- Add/edit/remove award sponsors
- Upload sponsor logos

**Hero Banner Management**:
- Upload banner images
- Set banner title, subtitle, button text, button destination
- Configure start date, end date
- Toggle active/inactive status
- Set display order
- Replace banner images
- Delete banners

**Notifications Management**:
- Send system-wide notifications
- Send targeted notifications to users
- Manage notification types

**Trending Content Management**:
- View weekly trending calculations
- Manually feature content as trending
- Adjust trending algorithms

**App Settings**:
- Configure platform settings
- Manage general configurations

## 4. Business Rules and Logic

### 4.1 Upload Plan Activation

**Critical Rule**: Plans must remain Pending until backend receives and verifies successful Lipila transaction. Never activate plan based on frontend payment success indication.

**Activation Flow**:
1. User initiates payment via Lipila
2. Lipila processes payment
3. Lipila sends webhook to backend OR backend queries Lipila API
4. Backend verifies transaction authenticity
5. If successful: Activate plan, update user allowance, set expiry date
6. If pending/failed/cancelled/insufficient funds/invalid: Keep plan inactive, allow retry

**Plan Expiry**:
- K10 plan: Single upload, no expiry
- K100 plan: Expires 7 days after activation
- K300 plan: Expires 1 year after activation
- Expired plans: User cannot upload until new plan purchased

**Admin Upload Exemption**:
- Admin/Super Admin upload unlimited MP3 and MP4 without paying any plan
- Admin uploads never require K10/K100/K300 packages or payment
- Admin uploads are approved by default or saveable as draft

### 4.2 Content Upload Authorization

**Upload Eligibility**:
- User must have active upload plan
- K10 plan: 1 upload remaining
- K100/K300 plans: Unlimited uploads within validity period
- Upload blocked if no active plan or allowance exhausted
- Admin/Super Admin: Unlimited uploads without plan

**Upload Processing**:
- MP3/MP4 files stored in Supabase Storage
- Metadata stored in Supabase PostgreSQL
- Content status: Pending approval by Admin (except admin uploads)
- Approved content: Visible on platform
- Rejected content: Not visible, user notified

### 4.3 Download System

**Download Process**:
1. User clicks download button on song or video
2. System retrieves actual MP3/MP4 file from Supabase Storage
3. File downloaded to user's device
4. Download count incremented only after successful download
5. Download record saved to database with user ID, content ID, download date

**Download Permissions**:
- Songs: Always downloadable
- Videos: Downloadable only if admin enables downloads for that video

**Download Tracking**:
- Display total download count on songs and videos
- Record every download in database
- Users view all downloaded content on My Downloads page

### 4.4 Global Search

**Search Functionality**:
- Fast search connected to Supabase database
- Search songs, videos, artists, albums, award nominees
- Live results while typing
- Search by title, artist, genre, album
- Show cover artwork and video thumbnails
- Click result to open content

**Search Filters**:
- All, Music, Videos, Artists, Awards

**Search Sorting**:
- Relevance, Newest, Most Played, Most Downloaded, Most Viewed

**Search Results**:
- Only show approved/public content
- Display result count
- Content cards with metadata

### 4.5 Notification System

**Notification Bell**:
- Animated bell icon in header
- Display unread notification count badge
- Click to open notification dropdown panel

**Notification Types**:
- Award winners announced
- Winner of the Month published
- Weekly trending updated
- New awards opened
- Voting opened/closing
- Nomination approved/rejected
- Successful/failed payments
- Package expiry reminders

**Notification Actions**:
- Open notification
- Mark as read
- Delete notification
- Mark all as read

**Notification Storage**:
- All notifications stored in Supabase database
- Users view notifications on Notifications page

### 4.6 Weekly Trending

**Trending Calculation**:
- Auto-calculate weekly: most played songs, most downloaded songs, most viewed videos, most liked songs, most shared content
- Calculation runs automatically at end of each week
- Store weekly rankings in database

**Trending Display**:
- Display on home page and dedicated Trending page
- Show ranking numbers
- Content details: title, artist, cover art/thumbnail, statistics

### 4.7 Content Ownership and Permissions

**User Permissions**:
- Users can edit/replace/delete only their own uploads
- Users can view only their own payment history
- Users can view only their own nominations and votes
- Users can view only their own downloads
- Users can view only their own notifications
- Enforced via Supabase Row Level Security (RLS)

**Admin Permissions**:
- Admins can manage all content (songs, videos, users, payments, awards, downloads, notifications, trending)
- Admins can approve/reject uploads
- Admins can change pricing
- Admins can enable/disable downloads per video
- Admins can publish Winner of the Month

### 4.8 Awards Nominee Registration

**Registration Flow**:
1. User selects award season and category
2. Fills registration form
3. Uploads images/files
4. Pays K25 fee via Lipila
5. Payment processed by Lipila
6. Backend verifies payment
7. Nomination created only after successful payment verification
8. Nomination status: Pending Payment → Pending Review → Approved/Rejected/Winner
9. If payment fails: Nomination not created, user can retry

**Nomination Statuses**:
- Pending Payment: Payment not yet verified
- Pending Review: Payment verified, awaiting admin approval
- Approved: Nomination approved by admin
- Rejected: Nomination rejected by admin
- Winner: Nominee selected as winner

### 4.9 Awards Voting

**Voting Flow**:
1. User selects nominee
2. Enters number of votes (minimum K5 per vote)
3. Selects payment method: Mobile Money or Card
4. Pays via Lipila
5. Backend verifies payment
6. Votes added only after successful payment verification
7. Vote totals updated
8. Payment record saved
9. User notified after verification
10. If payment fails: Votes not added, user can retry

**Vote Counting**:
- Each K5 = 1 vote
- K10 = 2 votes, K50 = 10 votes, etc.
- Votes tracked per user per nominee

### 4.10 Winner of the Month

**Winner Selection**:
- Admin selects one winner per month
- Admin uploads winner photo
- Admin enters artist name, award/category, month/year, prize, description
- Admin publishes winner

**Winner Display**:
- Feature on home page
- Display on awards page
- Show in notification panel

**Winner Notification**:
- Auto-notify all users when new monthly winner announced

### 4.11 Payment Security

**Backend Processing**:
- All Lipila API calls handled via Supabase Edge Functions
- Lipila credentials never exposed in frontend code
- Webhook verification for payment confirmation
- Transaction ID and idempotency protection to prevent duplicate processing

**Data Storage**:
- Store: user ID, amount, payment method, Lipila transaction ID, package, status, date, failure reason
- Never store: card number, CVV, PIN, sensitive card information

**Transaction Verification**:
- Backend queries Lipila API to verify transaction status
- Cross-check transaction ID and amount
- Activate plan/nomination/votes only after verification

**Server-Side Verification**:
- All payments verified server-side
- All downloads verified server-side
- All votes verified server-side
- All upload permissions verified server-side

### 4.12 Video Thumbnail Generation

**Thumbnail Creation**:
- Auto-generate thumbnail when MP4 uploaded
- Extract frame from video
- Store thumbnail in Supabase Storage

**Thumbnail Replacement**:
- When user replaces MP4 file, auto-generate new thumbnail
- Old thumbnail replaced with new one

### 4.13 Hero Banner Display Logic

**Banner Selection**:
- Display only active banners
- Filter by current date (between start date and end date)
- Sort by display order
- Rotate through eligible banners automatically

### 4.14 Content Statistics

**Music Statistics**:
- Track play count per song
- Track download count per song
- Track like count per song
- Track share count per song
- Update on each event
- Display on music page and user dashboard

**Video Statistics**:
- Track view count per video
- Track download count per video
- Track like count per video
- Track share count per video
- Update on each event
- Display on video page and user dashboard

## 5. Exceptions and Edge Cases

| Scenario | Handling |
|----------|----------|
| Payment fails during plan purchase | Plan remains inactive, display error message, allow user to retry payment |
| Insufficient funds during payment | Display message: \"Payment unsuccessful. Your payment could not be completed because there were insufficient funds. Please add sufficient funds and try again.\" Allow retry |
| User uploads file exceeding storage limit | Display error, prevent upload |
| User attempts upload without active plan | Block upload, prompt to purchase plan |
| Admin uploads content | No plan required, upload immediately |
| User attempts to edit another user's content | Block action, display error message |
| Admin changes plan price while user is purchasing | Use price at time of purchase initiation |
| Lipila webhook fails to deliver | Backend periodically queries Lipila API to verify pending transactions |
| User closes browser during payment | Payment status remains pending, user can check status in dashboard and retry if needed |
| Video upload fails mid-process | Display error, allow user to retry upload |
| Thumbnail generation fails | Use default placeholder thumbnail, log error for admin review |
| User attempts to vote with amount below K5 | Block vote, display minimum amount requirement |
| Nominee registration payment pending | Nomination not created, user can check payment status and retry |
| User's plan expires during active upload | Complete current upload, block subsequent uploads until new plan purchased |
| Download fails mid-process | Do not increment download count, allow user to retry download |
| User attempts to download video with downloads disabled | Block download, display message that downloads are disabled for this video |
| Search returns no results | Display \"No results found\" message |
| Notification bell shows incorrect unread count | Recalculate unread count from database |
| Weekly trending calculation fails | Log error, use previous week's trending data |
| Admin attempts to publish Winner of the Month without required fields | Block publish, display validation errors |
| User attempts to register as nominee without payment | Block registration, prompt to complete payment |
| User attempts to vote without payment | Block vote, prompt to complete payment |

## 6. Acceptance Criteria

1. User registers account and logs in successfully
2. User purchases K100 upload plan via Lipila Mobile Money, payment verified, plan activated with 7-day validity
3. User uploads MP3 file with metadata, file stored in Supabase Storage, metadata saved to database
4. Admin approves uploaded song, song appears on Music page
5. User plays song on Music page, play count increments
6. User downloads song, download count increments, download record saved to database
7. User searches for song by title, search results display song with cover art, user clicks to play
8. User receives notification for new award, notification bell shows unread badge, user opens notification
9. Admin uploads MP4 video without payment, video approved by default, appears on Videos page
10. User registers as nominee for award category, pays K25 via Lipila, nomination status changes to Pending Review after payment verification
11. Another user votes for nominee with K10 payment via Lipila, 2 votes added after payment verification
12. Admin publishes Winner of the Month, winner appears on home page, all users receive notification
13. Weekly trending auto-calculates at end of week, most played songs appear on Trending page

## 7. Out of Scope for This Release

- Social features: comments, user-to-user messaging, artist profiles with follower systems
- Advanced analytics: detailed listening patterns, demographic breakdowns, engagement heatmaps
- Playlist creation and management by users
- Collaborative playlists
- Offline download functionality
- Live streaming capabilities
- Podcast hosting and management
- Multi-language support beyond English
- Third-party integrations: Spotify, Apple Music, YouTube
- Advanced audio features: equalizer, audio effects, crossfade
- Video editing tools within platform
- Automated content moderation using AI
- Referral and affiliate programs
- Subscription tiers beyond upload plans (e.g., ad-free listening)
- Mobile native applications (iOS/Android apps)
- Push notifications
- Email marketing campaigns
- Advanced SEO optimization tools
- Content recommendation algorithms beyond basic trending/popular
- Multi-currency support beyond Kwacha
- International payment gateways beyond Lipila
- Advanced search filters: date range, duration, file size
- Batch download functionality
- Download history export
- Notification preferences customization
- Trending content export
- Award voting leaderboards
- Nominee profile pages
- Winner gallery with historical data visualization